package com.example.builletinboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuilletinboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
