package com.example.builletinboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BuilletinboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(BuilletinboardApplication.class, args);
	}

}
